import { Storage } from './storage.js';
import { UI } from './ui_components.js';

let currentUser = null; // 'admin' or 'parent'
let currentView = 'dashboard';

const navItems = [
    { id: 'dashboard', label: 'الرئيسية', icon: 'layout-dashboard', roles: ['admin'] },
    { id: 'students', label: 'الطلاب', icon: 'users', roles: ['admin'] },
    { id: 'attendance', label: 'الحضور', icon: 'calendar-check', roles: ['admin'] },
    { id: 'sync', label: 'المزامنة', icon: 'refresh-cw', roles: ['admin'] }
];

window.handleLogin = () => {
    const pin = document.getElementById('pin-input').value;
    if (pin === '1234') {
        currentUser = 'admin';
        document.getElementById('auth-screen').classList.add('hidden');
        renderApp();
    } else if (pin === '0000') {
        currentUser = 'parent';
        document.getElementById('auth-screen').classList.add('hidden');
        renderApp('parent-portal');
    } else {
        alert('رمز خاطئ');
    }
};

window.logout = () => {
    currentUser = null;
    document.getElementById('auth-screen').classList.remove('hidden');
    document.getElementById('pin-input').value = '';
};

function renderApp(view = 'dashboard') {
    currentView = view;
    Storage.init();
    renderNav();
    renderView();
    lucide.createIcons();
}

function renderNav() {
    const adminNav = document.getElementById('admin-nav');
    const mobileNav = document.getElementById('mobile-nav');
    
    if (currentUser === 'parent') {
        adminNav.innerHTML = '';
        mobileNav.innerHTML = `<button onclick="logout()" class="flex flex-col items-center gap-1 text-red-500">
            <i data-lucide="log-out"></i><span class="text-[10px]">خروج</span>
        </button>`;
        return;
    }

    const navHtml = navItems.map(item => `
        <button onclick="switchView('${item.id}')" class="flex flex-col md:flex-row items-center gap-3 p-3 rounded-xl transition-all ${currentView === item.id ? 'nav-item-active' : 'text-gray-500'}">
            <i data-lucide="${item.icon}"></i>
            <span class="text-[10px] md:text-base">${item.label}</span>
        </button>
    `).join('');

    adminNav.innerHTML = navHtml;
    mobileNav.innerHTML = navHtml + `<button onclick="logout()" class="flex flex-col items-center gap-1 text-red-500">
        <i data-lucide="log-out"></i><span class="text-[10px]">خروج</span>
    </button>`;
}

window.switchView = (view) => {
    currentView = view;
    renderApp(view);
};

function renderView() {
    const container = document.getElementById('view-container');
    const data = Storage.getData();

    switch (currentView) {
        case 'dashboard':
            container.innerHTML = `
                <h1 class="text-2xl font-bold mb-6">مرحباً، يا مشرف</h1>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    ${UI.renderCard('إجمالي الطلاب', data.students.length, 'users')}
                    ${UI.renderCard('متوسط الحضور', '92%', 'trending-up', 'bg-green-100 text-green-600')}
                </div>
                ${UI.renderLeaderboard(data.students)}
            `;
            break;

        case 'students':
            container.innerHTML = `
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold">إدارة الطلاب</h1>
                    <button onclick="showAddStudentModal()" class="bg-orange-600 text-white px-4 py-2 rounded-xl flex items-center gap-2">
                        <i data-lucide="plus"></i> إضافة طالب
                    </button>
                </div>
                <div class="space-y-4">
                    ${data.students.map(s => `
                        <div class="card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div>
                                <h3 class="font-bold text-lg">${s.name}</h3>
                                <p class="text-sm text-gray-500">المستوى: ${s.progress}</p>
                            </div>
                            <div class="flex items-center gap-2">
                                <button onclick="updatePoints('${s.id}', 5)" class="p-2 bg-green-50 text-green-600 rounded-lg">+5 نقاط</button>
                                <button onclick="editStudent('${s.id}')" class="p-2 bg-gray-100 rounded-lg"><i data-lucide="edit-3" class="w-4 h-4"></i></button>
                            </div>
                        </div>
                    `).join('') || '<p class="text-center py-12 text-gray-400">لا يوجد طلاب مضافين</p>'}
                </div>
            `;
            break;

        case 'attendance':
            const today = new Date().toISOString().split('T')[0];
            container.innerHTML = `
                <h1 class="text-2xl font-bold mb-6">سجل الحضور</h1>
                <div class="card p-6 mb-6">
                    <label class="block text-sm font-medium mb-2">اختر التاريخ (سبت/اثنين/أربعاء)</label>
                    <input type="date" id="attendance-date" value="${today}" class="w-full p-3 border rounded-xl">
                </div>
                <div class="card overflow-hidden">
                    <table class="w-full text-right">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="p-4 border-b">اسم الطالب</th>
                                <th class="p-4 border-b">الحالة</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.students.map(s => `
                                <tr>
                                    <td class="p-4 border-b">${s.name}</td>
                                    <td class="p-4 border-b">
                                        <select onchange="saveAttendance('${s.id}', this.value)" class="p-2 bg-gray-50 rounded-lg outline-none">
                                            <option value="present">حاضر</option>
                                            <option value="absent">غائب</option>
                                        </select>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            `;
            break;

        case 'sync':
            container.innerHTML = `
                <h1 class="text-2xl font-bold mb-6">المزامنة والبيانات</h1>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div class="card p-6 text-center">
                        <i data-lucide="download" class="w-12 h-12 mx-auto text-orange-600 mb-4"></i>
                        <h3 class="font-bold mb-2">تصدير البيانات</h3>
                        <p class="text-sm text-gray-500 mb-4">قم بتحميل نسخة احتياطية من كافة البيانات لمشاركتها.</p>
                        <button onclick="Storage.exportData()" class="w-full py-3 bg-orange-600 text-white rounded-xl">تحميل الملف</button>
                    </div>
                    <div class="card p-6 text-center">
                        <i data-lucide="upload" class="w-12 h-12 mx-auto text-blue-600 mb-4"></i>
                        <h3 class="font-bold mb-2">استيراد البيانات</h3>
                        <p class="text-sm text-gray-500 mb-4">قم برفع ملف البيانات لتحديث السجل الحالي.</p>
                        <input type="file" id="import-file" class="hidden" onchange="handleImport(event)">
                        <button onclick="document.getElementById('import-file').click()" class="w-full py-3 bg-blue-600 text-white rounded-xl">رفع ملف</button>
                    </div>
                </div>
            `;
            break;

        case 'parent-portal':
            container.innerHTML = `
                <div class="text-center mb-8">
                    <h1 class="text-2xl font-bold text-orange-600">بوابة أولياء الأمور</h1>
                    <p class="text-gray-500">أدخل رقم هوية الطالب للمتابعة</p>
                </div>
                <div class="card p-6 max-w-sm mx-auto">
                    <input type="text" id="parent-search-id" placeholder="رقم الهوية" class="w-full p-4 border rounded-2xl mb-4 text-center text-xl">
                    <button onclick="searchStudentAsParent()" class="w-full bg-orange-600 text-white py-4 rounded-2xl font-bold">بحث</button>
                </div>
                <div id="parent-result" class="mt-8"></div>
            `;
            break;
    }
    lucide.createIcons();
}

window.showAddStudentModal = () => {
    const name = prompt('الاسم الرباعي:');
    const dob = prompt('تاريخ الميلاد (YYYY-MM-DD):');
    const phone = prompt('رقم جوال ولي الأمر:');
    const nid = prompt('رقم الهوية:');
    
    if (name && nid) {
        Storage.addStudent({ name, dob, phone, nid });
        renderView();
    }
};

window.updatePoints = (id, pts) => {
    const data = Storage.getData();
    const student = data.students.find(s => s.id === id);
    if (student) {
        Storage.updateStudent(id, { points: (student.points || 0) + pts });
        renderView();
    }
};

window.handleImport = async (e) => {
    if (e.target.files[0]) {
        try {
            await Storage.importData(e.target.files[0]);
            alert('تم استيراد البيانات بنجاح');
            location.reload();
        } catch (err) {
            alert('خطأ في الملف: ' + err);
        }
    }
};

window.searchStudentAsParent = () => {
    const nid = document.getElementById('parent-search-id').value;
    const data = Storage.getData();
    const student = data.students.find(s => s.nid === nid);
    const resultDiv = document.getElementById('parent-result');

    if (student) {
        resultDiv.innerHTML = `
            <div class="card p-6 space-y-6">
                <div class="border-b pb-4">
                    <h2 class="text-xl font-bold">${student.name}</h2>
                    <p class="text-gray-500">رقم الهوية: ${student.nid}</p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div class="p-4 bg-orange-50 rounded-xl">
                        <p class="text-xs text-orange-600">المستوى</p>
                        <p class="font-bold">${student.progress}</p>
                    </div>
                    <div class="p-4 bg-orange-50 rounded-xl">
                        <p class="text-xs text-orange-600">النقاط</p>
                        <p class="font-bold">${student.points}</p>
                    </div>
                </div>
                <div>
                    <h4 class="font-bold mb-2">المهام القادمة:</h4>
                    <p class="p-4 bg-gray-50 rounded-xl text-gray-700">${student.tasks || 'لا يوجد ملاحظات حالية'}</p>
                </div>
                <button onclick="switchView('parent-portal')" class="w-full py-3 text-orange-600 border border-orange-200 rounded-xl">رجوع للبحث</button>
            </div>
        `;
    } else {
        alert('لم يتم العثور على طالب بهذا الرقم');
    }
    lucide.createIcons();
};


Storage.init();
