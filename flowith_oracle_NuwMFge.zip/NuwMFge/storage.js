export const Storage = {
    init() {
        if (!localStorage.getItem('tahfiz_data')) {
            const initialData = {
                students: [],
                attendance: {},
                settings: { centerName: 'مركز تحفيظ ملعب فلسطين' }
            };
            localStorage.setItem('tahfiz_data', JSON.stringify(initialData));
        }
    },

    getData() {
        return JSON.parse(localStorage.getItem('tahfiz_data'));
    },

    saveData(data) {
        localStorage.setItem('tahfiz_data', JSON.stringify(data));
    },

    addStudent(student) {
        const data = this.getData();
        student.id = Date.now().toString();
        student.points = 0;
        student.progress = 'جزء عم';
        student.tasks = '';
        data.students.push(student);
        this.saveData(data);
    },

    markAttendance(date, records) {
        const data = this.getData();
        data.attendance[date] = records;
        this.saveData(data);
    },

    updateStudent(id, updates) {
        const data = this.getData();
        const idx = data.students.findIndex(s => s.id === id);
        if (idx !== -1) {
            data.students[idx] = { ...data.students[idx], ...updates };
            this.saveData(data);
        }
    },

    exportData() {
        const data = localStorage.getItem('tahfiz_data');
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `tahfiz_data_${new Date().toISOString().split('T')[0]}.json`;
        a.click();
    },

    importData(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = JSON.parse(e.target.result);
                    if (data.students && data.attendance) {
                        localStorage.setItem('tahfiz_data', JSON.stringify(data));
                        resolve(true);
                    } else {
                        reject('Invalid format');
                    }
                } catch (err) {
                    reject(err);
                }
            };
            reader.readAsText(file);
        });
    }
};
