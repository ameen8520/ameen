export const UI = {
    renderCard(title, value, icon, colorClass = "bg-orange-100 text-orange-600") {
        return `
            <div class="card p-6 flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-500 font-medium">${title}</p>
                    <h3 class="text-2xl font-bold mt-1">${value}</h3>
                </div>
                <div class="w-12 h-12 ${colorClass} rounded-2xl flex items-center justify-center">
                    <i data-lucide="${icon}"></i>
                </div>
            </div>
        `;
    },

    renderLeaderboard(students) {
        const top10 = [...students].sort((a, b) => b.points - a.points).slice(0, 10);
        return `
            <div class="card p-6 mt-6">
                <h3 class="text-lg font-bold mb-4 flex items-center gap-2">
                    <i data-lucide="trophy" class="text-yellow-500"></i>
                    أفضل 10 طلاب (المجتهدين)
                </h3>
                <div class="space-y-4">
                    ${top10.map((s, i) => `
                        <div class="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                            <div class="flex items-center gap-3">
                                <span class="w-6 h-6 flex items-center justify-center bg-white border border-orange-200 rounded-full text-xs font-bold text-orange-600">${i + 1}</span>
                                <span class="font-medium">${s.name}</span>
                            </div>
                            <span class="text-orange-600 font-bold">${s.points} نقطة</span>
                        </div>
                    `).join('') || '<p class="text-center text-gray-400">لا يوجد بيانات حالياً</p>'}
                </div>
            </div>
        `;
    }
};
